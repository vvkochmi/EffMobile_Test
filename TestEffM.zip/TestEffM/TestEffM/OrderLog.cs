namespace TestEffM
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("OrderLog")]
    public partial class OrderLog
    {
        public int ID { get; set; }

        public DateTime FormTime { get; set; }

        public int DistrictID { get; set; }

        public DateTime OrderTime { get; set; }

        public int CountOrders { get; set; }

        public virtual District District { get; set; }
    }
}
