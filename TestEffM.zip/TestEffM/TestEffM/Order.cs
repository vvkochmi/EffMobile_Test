namespace TestEffM
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Order
    {
        [Key]
        public int Number { get; set; }

        public double Width { get; set; }

        public int DistrictID { get; set; }

        public DateTime OrderTime { get; set; }

        public virtual District District { get; set; }
    }
}
