﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestEffM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (TestContext db = new TestContext())
            {
                Districts.DataSource = db.Districts.ToList();
                Districts.ValueMember = "ID";
                Districts.DisplayMember = "DisName";
            }
        }

        private void Forming_Click(object sender, EventArgs e)
        {
            string str = $"Номер\tВес\tРайон заказа\tВремя доставки заказа\n";
            District district = Districts.SelectedItem as District;
            DateTime time = dateTimePicker1.Value;
            DateTime timeDiff = time.AddMinutes(30);
            if (district == null)
            {
                MessageBox.Show("Район не выбран, список заказов не сформирован");
                return;
            }
            using (TestContext db = new TestContext())
            {
                DataTable table = new DataTable();
                table.Columns.Add("Номер");
                table.Columns.Add("Вес");
                table.Columns.Add("Район");
                table.Columns.Add("Время");

                foreach (var order in db.Orders.Where(o => o.DistrictID == district.ID && o.OrderTime >= time && o.OrderTime <= timeDiff).ToList())
                {
                    DataRow row = table.NewRow();
                    row["Номер"] = order.Number;
                    row["Вес"] = order.Width;
                    row["Район"] = order.District.DisName;
                    row["Время"] = order.OrderTime;
                    table.Rows.Add(row);
                    str += $"{order.Number}\t{order.Width}\t{order.District.DisName}\t{order.OrderTime}\n";
                }
                dataGridView1.DataSource = table;

                db.OrderLogs.Add(new OrderLog() { DistrictID = district.ID, OrderTime = time, FormTime = DateTime.Now, CountOrders = dataGridView1.Rows.Count });
                db.Results.Add(new Result() { DistrictID = district.ID, FirstTime = time });
                db.SaveChanges();
            }

            using (FileStream file = new FileStream("Result.txt", FileMode.Create))
            {
                byte[] buffer = Encoding.Default.GetBytes(str);
                file.Write(buffer, 0, buffer.Length);
            }
        }
    }
}
